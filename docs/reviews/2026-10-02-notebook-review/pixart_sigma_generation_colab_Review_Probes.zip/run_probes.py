"""Probes for the Notebook Review Framework v1 review of tutorials/pixart_sigma_generation_colab.ipynb (row 66).

CPU only (CUDA_VISIBLE_DEVICES=-1), no model weights, no diffusers/transformers/peft. Evidence bases:
  P1/P2  direct execution of the repo's offline suite and static tools
  P3     direct execution of the carried BYOD loader/splitter (samples.py) on synthetic zips
  P4     arithmetic on the archived Kaggle T4 evaluation report of blob 99829b51 + a stand-in scorer
  P5     source inspection (string/AST checks on the notebook and modules)
  P6     documented execution evidence (archived run_summary.json)
Usage: python run_probes.py <worktree> <evidence_dir> <out_dir>
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
WT, EVID, OUT = (Path(a) for a in sys.argv[1:4])
NB = WT / "tutorials" / "pixart_sigma_generation_colab.ipynb"
results: dict = {}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(cmd, **kw):
    r = subprocess.run(cmd, cwd=WT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900, **kw)
    return {"cmd": " ".join(map(str, cmd)), "exit": r.returncode, "tail": (r.stdout + r.stderr)[-1500:]}


# ---- P1/P2: offline suite + static tools ----------------------------------------------------------------
env = dict(os.environ, PYTHONPATH=str(WT / "src"), KMP_DUPLICATE_LIB_OK="TRUE", PYTHONIOENCODING="utf-8")
results["P1_pytest"] = run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], env=env)
results["P2_build_check"] = run([sys.executable, "tools/build_notebook.py", "--check"], env=env)
results["P2_validator"] = run([sys.executable, "tools/validate_release_assets.py"], env=env)

# ---- P3: BYOD loader/splitter on synthetic zips ------------------------------------------------------------
sys.path.insert(0, str(WT / "src"))
sys.path.insert(0, str(WT / "tests"))
from conftest import synthetic_image  # noqa: E402
from pixart_sigma_generation_pipeline.samples import load_byod_dataset, split_dataset  # noqa: E402

tmp = OUT / "byod_tmp"
tmp.mkdir(parents=True, exist_ok=True)


def make_zip(name, rows, *, subdir="", extra=None, header="id,file,caption"):
    path = tmp / name
    with zipfile.ZipFile(path, "w") as z:
        lines = [header]
        for i, cap in enumerate(rows):
            buf = io.BytesIO()
            synthetic_image(seed=100 + i).save(buf, "JPEG")
            z.writestr(f"{subdir}img{i}.jpg", buf.getvalue())
            lines.append(f"r{i},img{i}.jpg,{cap}")
        z.writestr(f"{subdir}captions.csv", "\n".join(lines) + "\n")
        for k, v in (extra or {}).items():
            z.writestr(k, v)
    return path


def attempt(path):
    try:
        s = split_dataset(load_byod_dataset(path), seed=0)
        return {"accepted": True, "sizes": {k: len(v) for k, v in s.items()}}
    except Exception as exc:  # noqa: BLE001
        return {"accepted": False, "error": f"{type(exc).__name__}: {str(exc)[:160]}"}


p3 = {}
p3["stated_minimum_4_images_one_caption"] = attempt(make_zip("a.zip", ["cap A"] * 4))
p3["4_images_3plus1"] = attempt(make_zip("b.zip", ["cap A"] * 3 + ["cap B"]))
p3["5_images_one_caption"] = attempt(make_zip("c.zip", ["cap A"] * 5))
p3["6_images_one_caption"] = attempt(make_zip("d.zip", ["cap A"] * 6))
p3["8_images_two_captions_4_4"] = attempt(make_zip("e.zip", ["cap A", "cap B"] * 4))
p3["missing_captions_csv"] = attempt(tmp / "none.zip") if False else None
with zipfile.ZipFile(tmp / "nocsv.zip", "w") as z:
    z.writestr("img0.jpg", b"x")
p3["missing_captions_csv"] = attempt(tmp / "nocsv.zip")
p3["missing_column"] = attempt(make_zip("f.zip", ["cap A"] * 6, header="id,file,text"))
bad = make_zip("g.zip", ["cap A"] * 6)
with zipfile.ZipFile(bad, "a") as z:
    pass
with zipfile.ZipFile(tmp / "h.zip", "w") as z:
    z.writestr("captions.csv", "id,file,caption\nr0,notes.txt,cap A\n")
    z.writestr("notes.txt", "not an image")
p3["non_image_file"] = attempt(tmp / "h.zip")
(tmp / "i.zip").write_bytes(b"not a zip")
p3["not_a_zip"] = attempt(tmp / "i.zip")
results["P3_byod"] = p3

# ---- P4: real-photo ceiling self-inclusion --------------------------------------------------------------
rep = json.loads((EVID / "outputs" / "pixart_sigma_generation_evaluation_report.json").read_text(encoding="utf-8"))
rc = rep["real_photo_ceiling"]
per_caption = {}
for e in rc["per_image"]:
    per_caption.setdefault(e["prompt"], []).append(e["reference_similarity"] / 100)
# Two unit-norm embeddings a, b per caption: a . normalize(a+b) = sqrt((1+c)/2) with c = a.b,
# so c = 2 v^2 - 1, and the leave-one-out reference similarity of a is a . b = c.
loo = {}
for cap, vals in per_caption.items():
    assert len(vals) == 2 and abs(vals[0] - vals[1]) < 1e-9, (cap, vals)
    loo[cap] = 2 * vals[0] ** 2 - 1
loo_mean = sum(v for v in loo.values()) / len(loo) * 100
results["P4_ceiling"] = {
    "recorded_real_photo_reference_similarity": rc["reference_similarity"],
    "recorded_note": rc.get("note"),
    "photos_per_caption": {k[13:40]: len(v) for k, v in per_caption.items()},
    "self_inclusive_per_caption": {k[13:40]: round(v[0] * 100, 3) for k, v in per_caption.items()},
    "leave_one_out_per_caption": {k[13:40]: round(v * 100, 2) for k, v in loo.items()},
    "leave_one_out_mean": round(loo_mean, 2),
    "frozen_reference_similarity": rep["frozen"]["generations"]["reference_similarity"],
    "adapted_reference_similarity": rep["adapted"]["generations"]["reference_similarity"],
    "clip_prompt_similarity": rep["comparison"]["clip_prompt_similarity"],
    "label_accuracy": rep["comparison"]["label_accuracy"],
    "per_caption_reference_change": {
        b["prompt"][13:40]: round(a["reference_similarity"] - b["reference_similarity"], 3)
        for b, a in zip(rep["frozen"]["generations"]["per_image"][::2], rep["adapted"]["generations"]["per_image"][::2])
    },
    "history": rep["history"],
}

# Stand-in scorer: show real_photo_baseline scores each photo against a mean that includes itself.
import torch  # noqa: E402

from pixart_sigma_generation_pipeline.metrics import real_photo_baseline  # noqa: E402


class StandIn:
    identity = {"id": "stand-in", "revision": "0"}

    def __init__(self):
        g = torch.Generator().manual_seed(0)
        self.vecs = {}
        self.g = g

    def _v(self, key):
        if key not in self.vecs:
            self.vecs[key] = torch.nn.functional.normalize(torch.randn(16, generator=self.g), dim=0)
        return self.vecs[key]

    def image_embeddings(self, images):
        return torch.stack([self._v(("img", im.info.get("k"))) for im in images])

    def text_embeddings(self, texts):
        return torch.stack([self._v(("txt", t)) for t in texts])


from PIL import Image  # noqa: E402

recs = []
for i in range(2):
    im = Image.new("RGB", (8, 8))
    im.info["k"] = i
    recs.append({"caption": "c", "image": im})
s = StandIn()
base = real_photo_baseline(s, recs)
a, b = s.vecs[("img", 0)], s.vecs[("img", 1)]
results["P4_standin"] = {
    "baseline_reference_similarity": base["reference_similarity"],
    "self_inclusive_expected": round(float(a @ torch.nn.functional.normalize(a + b, dim=0)) * 100, 3),
    "leave_one_out_expected": round(float(a @ b) * 100, 3),
    "docstring_says": "references = the other records",
}

# ---- P5: source inspection ------------------------------------------------------------------------------
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = ["".join(c["source"]) for c in nb["cells"]]
md = "\n".join(c for c, cell in zip(cells, nb["cells"]) if cell["cell_type"] == "markdown")
code = [c for c, cell in zip(cells, nb["cells"]) if cell["cell_type"] == "code" and not cell.get("metadata", {}).get("dimer")]
pipe_src = (WT / "src/pixart_sigma_generation_pipeline/pipeline.py").read_text(encoding="utf-8")
adapt_src = pipe_src[pipe_src.index("    def adapt("): pipe_src.index("    # ---- artifacts")]
results["P5_source"] = {
    "metadata_dimer": nb["metadata"]["dimer"],
    "n_cells": len(nb["cells"]),
    "carried_module_lines": sum(c.count("\n") + 1 for c, cell in zip(cells, nb["cells"]) if cell.get("metadata", {}).get("dimer")),
    "carried_cells_have_cellView_form": [cell.get("metadata", {}).get("cellView") for cell in nb["cells"] if cell.get("metadata", {}).get("dimer")],
    "pip_install_into_kernel": any("'pip', 'install'" in c for c in code),
    "uses_uv": any("uv " in c or "'uv'" in c for c in code),
    "restart_raise_in_install_cell": any("Restart the runtime" in c for c in code),
    "states_real_photos_1_0": "real photographs' 1.0" in md,
    "double_brace_record": "{{id, image, caption}}" in md,
    "display_calls": any(k in c for c in code for k in ("display(", "IPython", "plt.")),
    "real_ceiling_note_printed": any("real_ceiling['note']" in c or "real_ceiling[\"note\"]" in c for c in code),
    "adapt_resets_lora": any(k in adapt_src for k in ("reset_lora", "zero_(", "self.adapter is not None")),
    "adapt_epoch0_label": "frozen model (LoRA at initialisation: B = 0)" in adapt_src,
    "byod_rerun_instruction": "re-run from that cell" in md,
    "guided_markers": {k: (k.lower() in md.lower()) for k in ("How to use", "Roadmap", "Glossary", "Predict", "Check your reasoning", "Troubleshoot", "Infrastructure", "conclusion template", "What to notice")},
    "pretraining_overlap_statement": any(k in md.lower() for k in ("overlap", "pretraining data", "laion-2b may", "may have seen")),
    "independence_statement": any(k in md.lower() for k in ("independent", "same individual", "grouped")),
    "hold_out_by_caption_text": "Hold out by caption, not by image" in md,
    "spec_declared": nb["metadata"]["dimer"]["notebook_spec"],
}

# ---- P6: documented execution evidence ------------------------------------------------------------------
rs = json.loads((EVID / "run_summary.json").read_text(encoding="utf-8"))
blob = subprocess.run(["git", "rev-parse", "HEAD:tutorials/pixart_sigma_generation_colab.ipynb"], cwd=WT, capture_output=True, text=True).stdout.strip()
results["P6_record"] = {
    "main_blob": blob,
    "record_blob": rs["identity"]["committed_blob"],
    "blob_match": blob == rs["identity"]["committed_blob"],
    "passes": [{"attempt": p["attempt"], "ok": p["ok"], "error_tail": (p.get("error") or "")[-260:]} for p in rs["runner"]["passes"]],
    "cell_seconds": {c["cell"]: c["ended"][11:19] for c in rs["cells"]},
    "adaptation_seconds": rep["adaptation_seconds"],
}

(OUT / "results.json").write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")
manifest = {str(p.relative_to(WT)).replace("\\", "/"): sha(p) for p in [
    NB, WT / "src/pixart_sigma_generation_pipeline/pipeline.py", WT / "src/pixart_sigma_generation_pipeline/metrics.py",
    WT / "src/pixart_sigma_generation_pipeline/samples.py", WT / "tools/build_notebook.py", WT / "tools/notebook_template.py",
    WT / "tutorials/README.md", WT / "docs/release-verification.md", WT / "STATUS.md"]}
manifest["evidence:run_summary.json"] = sha(EVID / "run_summary.json")
manifest["evidence:evaluation_report.json"] = sha(EVID / "outputs" / "pixart_sigma_generation_evaluation_report.json")
(OUT / "source_manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
print(json.dumps({k: v for k, v in results.items() if k.startswith(("P1", "P2", "P3", "P4_s"))}, indent=1, default=str)[:6000])
